import { five } from '../src';

describe('five', () => {
  it('is five', () => {
    expect(five).toEqual(5);
  });
});
