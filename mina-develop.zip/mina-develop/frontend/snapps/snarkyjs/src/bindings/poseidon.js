// TODO
export function poseidon(fields) {
  return fields[0];
}
