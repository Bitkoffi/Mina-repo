export class Scalar { }
export class Group { }
