import { Field } from './plonk';

export const poseidon: (x: Field[]) => Field;
