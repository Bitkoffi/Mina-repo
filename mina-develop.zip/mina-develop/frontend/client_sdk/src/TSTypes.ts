export type uint32 = number | bigint | string;
export type uint64 = number | bigint | string;
