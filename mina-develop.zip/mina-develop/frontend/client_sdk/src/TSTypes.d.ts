export declare type uint32 = number | bigint | string;
export declare type uint64 = number | bigint | string;
