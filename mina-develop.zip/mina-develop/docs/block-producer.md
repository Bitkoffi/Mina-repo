# Block producer


## Block production Scheduling
[block-production-scheduling]: #block-production-scheduling

![](res/block_production_fsm.png)
