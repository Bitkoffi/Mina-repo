## Docs

This folder contains some of the docs for codaprotocol.

The docs that are available to view on [the website](https://codaprotocol.com/docs/) can be edited/viewed [here](../frontend/website/docs)
