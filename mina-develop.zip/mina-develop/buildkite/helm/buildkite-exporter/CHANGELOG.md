0.1.2:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking

0.1.3:
------
- update default exporter image version (0.1.0 => 0.2.0)

0.1.4:
------
- fix metrics port type interpretation (ensure cast to int)
- update default exporter image version (0.2.0 => 0.2.1)

