var mina = require("../../../../_build/default/src/app/client_sdk/client_sdk.bc.js").minaSDK;

console.log("Running client SDK unit tests");
mina.runUnitTests () ();
console.log("Done.");
