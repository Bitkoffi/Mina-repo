// +build tools

package tools

import (
	_ "github.com/campoy/jsonenums"
)
