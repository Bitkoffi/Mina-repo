#!/bin/bash

. lib.sh

req /network/options '{ network_identifier: { blockchain: "mina", network: "debug" }, metadata: {} }'

