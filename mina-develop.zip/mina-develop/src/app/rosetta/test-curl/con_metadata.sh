#!/bin/bash

. lib.sh

req '/construction/metadata' '{"network_identifier":{"blockchain":"mina","network":"debug"},"options":{"sender":"B62qmnkbvNpNvxJ9FkSkBy5W6VkquHbgN2MDHh1P8mRVX3FQ1eWtcxV","token_id":"1"},"public_keys":[]}'
