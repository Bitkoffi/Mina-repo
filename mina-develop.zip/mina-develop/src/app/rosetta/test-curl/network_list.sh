#!/bin/bash

. lib.sh

req /network/list '{ metadata: {} }'

