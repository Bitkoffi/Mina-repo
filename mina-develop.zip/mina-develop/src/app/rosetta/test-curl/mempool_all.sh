#!/bin/bash

. lib.sh

req /mempool '{ network_identifier: { blockchain: "mina", network: "debug" }, metadata: {} }'

