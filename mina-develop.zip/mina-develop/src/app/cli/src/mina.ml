let () = Mina_cli_entrypoint.linkme
