ocaml-sodium version: 0.6
libsodium version: 1.0.16
