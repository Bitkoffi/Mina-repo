tsc --lib esnext,esnext.bigint spec.ts
