The Project Grant program is designed to encourage community members to work on projects related to developing the Mina protocol and community.

Please visit https://minaprotocol.com/grants for more details.